//
//  SubmitViewController.swift
//  Loginpage
//
//  Created by IE13 on 03/11/23.
//

import UIKit

class SubmitViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.hidesBackButton = true
    }
     @IBAction func logoutButtonAction(_ sender: UIButton) {
         if let loginViewController = storyboard?.instantiateViewController(withIdentifier: "LoginViewController") as? LoginViewController {
             navigationController?.pushViewController(loginViewController, animated: true)
         }
     }
}
