//
//  LoginViewController.swift
//  Loginpage
//
//  Created by IE13 on 03/11/23.
//

import UIKit
import LocalAuthentication

class LoginViewController: UIViewController, UITextFieldDelegate {
    @IBOutlet private var emailTextField: UITextField!
    @IBOutlet private var passwordTextField: UITextField!
    @IBOutlet private var showHideIconChagePasswordButton: UIButton!
    @IBOutlet private var visibleButton: UIButton!
    var isShow: Bool = true
    var isVisible: Bool = false
    override func viewDidLoad() {
        super.viewDidLoad()
        emailTextField.delegate = self
        passwordTextField.delegate = self
        navigationItem.hidesBackButton = true
        //        let visible = UserDefaults.standard.bool(forKey: "checkbox")
        //        let email = KeychainWrapper.standard.string(forKey: "Email")
        //        let password = KeychainWrapper.standard.string(forKey: "Password")
        //
        //        if visible{
        //            isVisible = true
        //            emailTextField.text = email
        //            passwordTextField.text = password
        //            let image2 = UIImage(named: "checked")
        //            visibleButton.setImage(image2, for: .normal)
        //        }
    }
    @IBAction func continueButton(_ sender: UIButton) {
        if (emailTextField.text ?? "").isEmpty && (passwordTextField.text ?? "").isEmpty {
            let alertController = UIAlertController(title: "Alert", message: "Please enter correct email and password", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: { _ in}))
            self.present(alertController, animated: true)
            return
        }
        if (emailTextField.text ?? "").isEmpty {
            let alertController = UIAlertController(title: "Invalid Email", message: "Your email is empty.", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: { _ in}))
            self.present(alertController, animated: true)
            return
        }
        if (passwordTextField.text ?? "").isEmpty {
            let alertController = UIAlertController(title: "Invalid Password", message: "Your password is empty", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: { _ in}))
            self.present(alertController, animated: true)
            return
        }
        if !isValidEmail(emailTextField.text ?? "") {
            let alertController = UIAlertController(title: "Invalid Email", message: "Please enter correct email.", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: { _ in}))
            self.present(alertController, animated: true)
            return
        }
        if !passwordValidate(password: passwordTextField.text ?? "") {
            let alertController = UIAlertController(title: "Invalid Password", message: "Please enter correct password.", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: { _ in}))
            self.present(alertController, animated: true)
            return
        }
        setDetails()
        if isValidEmail(emailTextField.text ?? "") && passwordValidate(password: passwordTextField.text ?? "") {
            //            if let loginViewController = storyboard?.instantiateViewController(withIdentifier: "SubmitViewController") as? SubmitViewController {
            //                navigationController?.pushViewController(loginViewController, animated: true)
            //                emailTextField.text = ""
            //                passwordTextField.text = ""
            //            }
        }
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        emailTextField.resignFirstResponder()
        passwordTextField.resignFirstResponder()
        return true
    }
    @IBAction func forgotPasswordButton(_ sender: UIButton) {
        let image2 = UIImage(systemName: "eye.fill")
        sender.setImage(image2, for: .normal)
    }
    public func isValidPassword() -> Bool {
        let passwordRegex = "^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])[0-9a-zA-Z!@#$%^&*()\\-_=+{}|?>.<,:;~`’]{8,}$"
        return NSPredicate(format: "SELF MATCHES %@", passwordRegex).evaluate(with: self)
    }
    @IBAction func showHidePasswordAction(_ sender: UIButton) {
        if isShow {
            let image2 = UIImage(systemName: "eye.fill")
            showHideIconChagePasswordButton.setImage(image2, for: .normal)
            isShow = false
        } else {
            let image2 = UIImage(systemName: "eye.slash.fill")
            showHideIconChagePasswordButton.setImage(image2, for: .normal)
            isShow = true
        }
        passwordTextField.isSecureTextEntry = isShow
    }
    func isValidEmail(_ email: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPred = NSPredicate(format: "SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: email)
    }
    func passwordValidate(password: String) -> Bool {
        let regularExpression = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[$@$!%*?&])[A-Za-z\\d$@$!%*?&]{8,}"
        let passwordValidation = NSPredicate.init(format: "SELF MATCHES %@", regularExpression)
        return passwordValidation.evaluate(with: password)
    }
    @IBAction func checkedButtonAction(_ sender: UIButton) {
        if isVisible {
            let image2 = UIImage(named: "uncheckbox")
            visibleButton.setImage(image2, for: .normal)
        } else {
            let image2 = UIImage(named: "checked")
            visibleButton.setImage(image2, for: .normal)
        }
        isVisible = !isVisible
    }
    func setDetails() {
        UserDefaults.standard.set(isVisible, forKey: "checkbox")
        KeychainWrapper.standard.set(emailTextField.text!, forKey: "Email")
        KeychainWrapper.standard.set(passwordTextField.text!, forKey: "Password")
    }
    @IBAction func authenticationButtonAction(_ sender: UIButton) {
        let context = LAContext()
        var error: NSError?
        if context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error) {
            let reason = "Identify yourself!"
            context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: reason) {
                [weak self] success, authenticationError in
                DispatchQueue.main.async {
                    if success {
                        let visible = UserDefaults.standard.bool(forKey: "checkbox")
                        let email = KeychainWrapper.standard.string(forKey: "Email")
                        let password = KeychainWrapper.standard.string(forKey: "Password")
                        if visible {
                            self?.isVisible = true
                            self?.emailTextField.text = email
                            self?.passwordTextField.text = password
                            let image2 = UIImage(named: "checked")
                            self?.visibleButton.setImage(image2, for: .normal)
                        }
                    } else {
                        let alertController = UIAlertController(title: "Authentification field", message: "You could not be verified; please try again", preferredStyle: .alert)
                        alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: { _ in}))
                        self?.present(alertController, animated: true)
                        return
                    }
                }
            }
        } else {
            // no biometry
            let alertController = UIAlertController(title: "Biometry unavilable", message: "Your device is not configured for biometric authentification.", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: { _ in}))
            self.present(alertController, animated: true)
            return
        }
    }
}
