//
//  forgotViewController.swift
//  Loginpage
//
//  Created by IE13 on 03/11/23.
//

import UIKit

class ForgotViewController: UIViewController, UITextFieldDelegate {
    @IBOutlet private var emailTextField: UITextField!
    override func viewDidLoad() {
        // super.viewDidLoad()
    }
    @IBAction func emailTextFieldAction(_ sender: UIButton) {
        if !isValidEmail(emailTextField.text ?? "") {
            let alertController = UIAlertController(title: "Invalid Email", message: "Please enter correct email.", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: { _ in}))
            self.present(alertController, animated: true)
            return
        }
        if  isValidEmail(emailTextField.text ?? "") {
            if let loginViewController = storyboard?.instantiateViewController(withIdentifier: "SubmitViewController") as? SubmitViewController {
                navigationController?.pushViewController(loginViewController, animated: true)
            }
        }
    }
    func isValidEmail(_ email: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPred = NSPredicate(format: "SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: email)
    }
}
