//
//  CreateAccountViewController.swift
//  Loginpage
//
//  Created by IE13 on 02/11/23.
//

import UIKit

class CreateAccountViewController: UIViewController, UITextFieldDelegate {
    @IBOutlet private var nameTextField: UITextField!
    @IBOutlet private var emailTextField: UITextField!
    @IBOutlet private var passwordTextField: UITextField!
    @IBOutlet private var confirmPasswordTextField: UITextField!
    @IBOutlet private var showHidePasswordButton: UIButton!
    var isShow: Bool = true
    override func viewDidLoad() {
        super.viewDidLoad()
        nameTextField.delegate = self
        emailTextField.delegate = self
        passwordTextField.delegate = self
        confirmPasswordTextField.delegate = self
    }
    @IBAction func signUpButton(_ sender: UIButton) {
        if(nameTextField.text ?? "").isEmpty {
            let alertController = UIAlertController(title: "Alert", message: "Please enter your name.", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: { _ in}))
            self.present(alertController, animated: true)
            return
        } else if (emailTextField.text ?? "").isEmpty {
            let alertController = UIAlertController(title: "Alert", message: "Please enter your email.", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: { _ in}))
            self.present(alertController, animated: true)
            return
        } else if (passwordTextField.text ?? "").isEmpty {
            let alertController = UIAlertController(title: "Alert", message: "Please enter your password.", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: { _ in}))
            self.present(alertController, animated: true)
            return
        } else if (confirmPasswordTextField.text ?? "").isEmpty {
            let alertController = UIAlertController(title: "Alert", message: "Please enter confirm password.", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: { _ in}))
            self.present(alertController, animated: true)
            return
        } else if !isValidEmail(emailTextField.text ?? "") {
            let alertController = UIAlertController(title: "Invalid Email", message: "Please enter correct email.", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: { _ in}))
            self.present(alertController, animated: true)
            return
        } else if !passwordValidate(password: passwordTextField.text ?? "") {
            let alertController = UIAlertController(title: "Invalid Password", message: "Please enter corrrect password.", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: { _ in}))
            self.present(alertController, animated: true)
            return
        } else if passwordTextField.text != confirmPasswordTextField.text {
            let alertController = UIAlertController(title: "Alert", message: "Your password and confirmation password do not match.", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: { _ in}))
            self.present(alertController, animated: true)
            return
        } else if isValidEmail(emailTextField.text ?? "") && passwordValidate(password: passwordTextField.text ?? "") && passwordTextField.text == confirmPasswordTextField.text {
            if let loginViewController = storyboard?.instantiateViewController(withIdentifier: "NameViewController") as? NumberViewController {
                navigationController?.pushViewController(loginViewController, animated: true)
                nameTextField.text = ""
                emailTextField.text = ""
                passwordTextField.text = ""
                confirmPasswordTextField.text = ""
            }
        }
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        nameTextField.resignFirstResponder()
        emailTextField.resignFirstResponder()
        passwordTextField.resignFirstResponder()
        confirmPasswordTextField.resignFirstResponder()
        return true
    }
    func isValidEmail(_ email: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPred = NSPredicate(format: "SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: email)
    }
    func passwordValidate(password: String) -> Bool {
        let regularExpression = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[$@$!%*?&])[A-Za-z\\d$@$!%*?&]{8,}"
        let passwordValidation = NSPredicate.init(format: "SELF MATCHES %@", regularExpression)
        return passwordValidation.evaluate(with: password)
    }
    @IBAction func showHidePasswordAction(_ sender: UIButton) {
        if isShow {
            let image2 = UIImage(systemName: "eye.fill")
            showHidePasswordButton.setImage(image2, for: .normal)
            isShow = false
        } else {
            let image2 = UIImage(systemName: "eye.slash.fill")
            showHidePasswordButton.setImage(image2, for: .normal)
            isShow = true
        }
        passwordTextField.isSecureTextEntry = isShow
    }
}
