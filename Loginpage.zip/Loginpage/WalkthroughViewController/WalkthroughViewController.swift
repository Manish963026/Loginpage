//
//  RootViewController.swift
//  Loginpage
//
//  Created by IE13 on 06/11/23.
//

import UIKit
class WalkthroughViewController: UIViewController {
    private var pageViewController: UIPageViewController!
    @IBOutlet private var skipButton: UIButton!
    @IBOutlet private var pageControl: UIPageControl!
    @IBOutlet private var nextButton: UIButton!
    private var index: Int = 1
    var viewControllerList: [UIViewController] = {
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let firstPageViewController = storyBoard.instantiateViewController(withIdentifier: "FirstPageViewController")
        let secondPageViewController = storyBoard.instantiateViewController(withIdentifier: "SecondPageViewController")
        let thirdPageViewController = storyBoard.instantiateViewController(withIdentifier: "ThirdPageViewController")
        return [firstPageViewController, secondPageViewController, thirdPageViewController]
    }()
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "PageViewController" {
            pageViewController = segue.destination as? UIPageViewController
            if let firstViewController = viewControllerList.first {
                pageViewController.setViewControllers([firstViewController], direction: .forward, animated: true, completion: nil)
            }
        }
    }
    @IBAction func nextPageViewAction(_ sender: Any) {
        if index>=viewControllerList.count {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let viewContoller = storyboard.instantiateViewController(withIdentifier: "LoginViewController")
            navigationController?.pushViewController(viewContoller, animated: true)
            return
        }
        if let viewController = viewControllerList[index] as? UIViewController {
            pageViewController.setViewControllers([viewController], direction: .forward, animated: false, completion: nil)
            pageControl.currentPage = index
            index += 1
        }
        if index>=viewControllerList.count {
            skipButton.isHidden = true
        }
    }
}
