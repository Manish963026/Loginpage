////
////  PageViewController.swift
////  Loginpage
////
////  Created by IE13 on 04/11/23.
////
// import UIKit
// class PageViewController: UIPageViewController, UIPageViewControllerDataSource {
//
//    let sb = UIStoryboard(name: "Main", bundle: nil)
//    var viewControllerlist: [UIViewController] = {
//        let sb = UIStoryboard (name: "Main", bundle: nil)
//        let vc3 = sb.instantiateViewController (withIdentifier:"ThirdPageViewController")
//        let vc2 = sb.instantiateViewController (withIdentifier: "SecondPageViewController")
//        let vc1 = sb.instantiateViewController (withIdentifier: "FirstPageViewController")
//        return [vc1,vc2, vc3]
//    }()
//
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        self.dataSource = self
//        if let firstViewController = viewControllerlist.first {
//            self.setViewControllers([firstViewController], direction: .reverse, animated: true)
//        }
//    }
//
//    func pageViewController( _ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
//        guard let vcIndex = viewControllerlist.index (of: viewController) else {return nil}
//        let previousIndex = vcIndex - 1
//        guard previousIndex >= 0 else {return nil}
//        guard viewControllerlist.count > previousIndex else {return nil}
//        return viewControllerlist[previousIndex]
//    }
//
//    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
//        guard let vcIndex = viewControllerlist.index (of: viewController) else {return nil}
//        let nextIndex = vcIndex + 1
//        guard viewControllerlist.count != nextIndex else { return nil}
//        guard viewControllerlist.count > nextIndex else { return nil }
//        return viewControllerlist[nextIndex]
//    }
//}

