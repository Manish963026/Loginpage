//
//  BirthdayViewController.swift
//  Loginpage
//
//  Created by IE13 on 06/11/23.
//

import UIKit

class BirthdayViewController: UIViewController {
    @IBOutlet private var selectBirthdayLabel: UILabel!
    @IBOutlet private var datePicker: UIDatePicker!
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.hidesBackButton = true
    }
    @IBAction func datePickerAction(_ sender: UIDatePicker) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy hh:mm"
        let strDate = dateFormatter.string(from: sender.date)
        self.selectBirthdayLabel.text = strDate
    }
    @IBAction func birthdayActionButton(_ sender: UIButton) {
        if (selectBirthdayLabel.text ?? "").isEmpty {
            let alertController = UIAlertController(title: "Alert", message: "Please select your birthday date.", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: { _ in}))
            self.present(alertController, animated: true)
            return
        } else {
            if let loginViewController = storyboard?.instantiateViewController(withIdentifier: "GenderViewController") as? GenderViewController {
                navigationController?.pushViewController(loginViewController, animated: true)
            }
        }
    }
}
