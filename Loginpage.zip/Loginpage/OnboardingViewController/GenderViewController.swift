//
//  GenderViewController.swift
//  Loginpage
//
//  Created by IE13 on 06/11/23.
//

import UIKit

class GenderViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.hidesBackButton = true
    }
    @IBAction func genderActionButton(_ sender: UIButton) {
        if let controller = storyboard?.instantiateViewController(withIdentifier: "CongratulationViewController") as? CongratulationViewController {
            navigationController?.pushViewController(controller, animated: true)
        }
    }
}
