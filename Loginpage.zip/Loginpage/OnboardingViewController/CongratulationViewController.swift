//
//  CongratulationViewController.swift
//  Loginpage
//
//  Created by IE13 on 06/11/23.
//

import UIKit

class CongratulationViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.hidesBackButton = true
    }
    @IBAction func goToHomeAction(_ sender: UIButton) {
//        if let loginViewController = storyboard?.instantiateViewController(withIdentifier: "SubmitViewController") as? SubmitViewController {
//            navigationController?.pushViewController(loginViewController, animated: true)
//        }
    }
}
