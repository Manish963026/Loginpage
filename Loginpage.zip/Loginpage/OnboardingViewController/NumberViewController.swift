//
//  NameViewController.swift
//  Loginpage
//
//  Created by IE13 on 06/11/23.
//

import UIKit

class NumberViewController: UIViewController, UITextFieldDelegate {
    @IBOutlet private var nameTextField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        nameTextField.delegate = self
        navigationItem.hidesBackButton = true
        let doneToolbar: UIToolbar = UIToolbar(frame: CGRect.init(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 50))
        doneToolbar.barStyle = .default
        let flexSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let done: UIBarButtonItem = UIBarButtonItem(title: "Done", style: .done, target: self, action: #selector(self.doneButtonAction))
        let items = [flexSpace, done]
        doneToolbar.items = items
        doneToolbar.sizeToFit()
        nameTextField.inputAccessoryView = doneToolbar
    }
    @objc func doneButtonAction() {
        nameTextField.resignFirstResponder()
    }
    @IBAction func continueButtonAction(_ sender: UIButton) {
        if isValidPhone(phone: nameTextField.text ?? "") {
            if let loginViewController = storyboard?.instantiateViewController(withIdentifier: "BirthdayViewController") as? BirthdayViewController {
                navigationController?.pushViewController(loginViewController, animated: true)
                nameTextField.text = ""
            }
        } else {
            let alertController = UIAlertController(title: "Alert", message: "Please enter your mobile number.", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: { _ in}))
            self.present(alertController, animated: true)
            return
        }
    }
    func isValidPhone(phone: String) -> Bool {
        let phoneRegex = "^[0-9+]{0,1}+[0-9]{5,16}$"
        let phoneTest = NSPredicate(format: "SELF MATCHES %@", phoneRegex)
        return phoneTest.evaluate(with: phone)
    }
}

