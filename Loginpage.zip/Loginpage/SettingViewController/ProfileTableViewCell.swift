//
//  ProfileTableViewCell.swift
//  Loginpage
//
//  Created by IE13 on 15/11/23.
//

import UIKit

class ProfileTableViewCell: UITableViewCell {

    @IBOutlet weak var profileNameLable: UILabel!
//    override func awakeFromNib() {
//        super.awakeFromNib()
//        // Initialization code
//    }
    override func setSelected(_ selected: Bool, animated: Bool) {
       // super.setSelected(selected, animated: animated)
// Configure the view for the selected state
    }

}
