//
//  HelpCenterViewCell.swift
//  Loginpage
//
//  Created by IE13 on 16/11/23.
//

import UIKit

class HelpCenterViewCell: UITableViewCell {

    @IBOutlet weak var textNameLabel: UILabel!
    @IBOutlet weak var textDescLabel: UILabel!
//    override func awakeFromNib() {
//        super.awakeFromNib()
//        // Initialization code
//    }

//    override func setSelected(_ selected: Bool, animated: Bool) {
//        super.setSelected(selected, animated: animated)
//    }
}
